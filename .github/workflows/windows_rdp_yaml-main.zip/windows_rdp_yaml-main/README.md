# ☕ Support My Work

If you find my work helpful, support me by buying a coffee:  
👉 [https://buymeacoffee.com/kumaresankp](https://buymeacoffee.com/kumaresankp)

---

## 📺 Watch My YouTube Tutorial

[![Watch on YouTube](https://img.youtube.com/vi/RiLfMxWXXsA/0.jpg)](https://youtu.be/RiLfMxWXXsA)

---

## 🌐 Connect with Me

- **Instagram**: [@programmingwithkumaresan18](https://instagram.com/programmingwithkumaresan18)
- **X (Twitter)**: [@kumaresankp21](https://x.com/kumaresankp21)
- **LinkedIn**: [kumaresankp21](https://linkedin.com/in/kumaresankp21)
- **Facebook Group**: [Join Here](https://www.facebook.com/profile.php?id=61563662246215)
- **Threads**: [@programmingwithkumaresan18](https://www.threads.com/@programmingwithkumaresan18)
- **Telegram**: [t.me/kumaresankp](https://t.me/kumaresankp)
- **Medium**: [@kumaresankp21](https://medium.com/@kumaresankp21)
- **GitHub**: [github.com/kumaresankp](https://github.com/kumaresankp)

---

## 📚 Courses From Me

- **Python Course**  
  [Python Programming - From Beginner to Advanced](https://www.udemy.com/course/python-programming-from-beginner-to-advanced-in-one-course/)

- **NumPy Course**  
  [Python NumPy Tutorial for Beginners and Advanced](https://www.udemy.com/course/python-numpy-tutorial-for-beginners-and-advanced/)

- **Git & GitHub Full Course** *(YouTube)*  
  [Watch Now](https://youtu.be/UKuPrJOenWQ?si=lG8o_yIRI3qOvUkg)
